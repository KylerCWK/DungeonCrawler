#keeps track of where everything spawns. Floor, wall, door, chest

#DEFINE WHAT GOES IN THE LEVEL

#DEFINE HOW THOSE THINGS GO INTO THE LEVEL