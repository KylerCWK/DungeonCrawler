#show the sprite

#REACT to WASD
#REACT some other attack button

#health value that decreases when attacked.
#health value that increases when given potion