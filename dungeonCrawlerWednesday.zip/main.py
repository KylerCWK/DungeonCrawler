import pygame, sys
from pygame.locals import*

'''
COMPLETION GOALS:
-Add images to the code!
-Basic main (screen compatibility)
-Begin level design algorithm (brain)
-saving and loading??? how do we do that?

-How does this stuff compare to the Bubble Pop project?
'''

pygame.init()

size = (width, height) = (pygame.display.Info().current_w, pygame.display.Info().current_h)
screen = pygame.display.set_mode(size)
color = (0, 0, 0)


#def main():
  #what's going on during the game?


if __name__ == "__main__":
    main()
