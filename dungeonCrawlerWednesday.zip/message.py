#cover broadcasting
#health, number of monsters, is there a chest?
#what level we're on?