#show the sprite

#move on their own. spawn at a random location and maybe bounce around (based on wall)