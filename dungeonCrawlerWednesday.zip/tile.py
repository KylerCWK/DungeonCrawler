#clone itself
#how many tiles?